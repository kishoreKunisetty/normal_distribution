from setuptools import setup

setup(name='normal_distribution',
      version='0.1',
      description='Gaussian distributions',
      packages=['normal_distribution'],
      author = 'Kishore',
      zip_safe=False)
